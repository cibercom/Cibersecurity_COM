# Raphael
Raphael is a tiny antivirus software based on [Qt Quick](https://www.qt.io/) and [ClamAV](https://www.clamav.net/)  

You can try to use this software with [Eicar Virus Sample](https://www.eicar.org/?page_id=3950).  

## Preview

![Main](https://github.com/hubenchang0515/resource/blob/master/Raphael/main.png?raw=true)
![Scan](https://github.com/hubenchang0515/resource/blob/master/Raphael/scan.png?raw=true)
![Result](https://github.com/hubenchang0515/resource/blob/master/Raphael/result.png?raw=true)
![Update](https://github.com/hubenchang0515/resource/blob/master/Raphael/update.png?raw=true)