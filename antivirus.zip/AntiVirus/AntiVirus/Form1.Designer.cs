﻿namespace AntiVirus
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.miniTimer_ThemeContainer1 = new MiniTimer.Class1.MiniTimer_ThemeContainer();
            this.playUI_Label2 = new PlayUI.Class1.PlayUI_Label();
            this.playUI_Label1 = new PlayUI.Class1.PlayUI_Label();
            this.pictureBox8 = new System.Windows.Forms.PictureBox();
            this.miniTimer_ButtonBase1 = new MiniTimer.Class1.MiniTimer_ButtonBase();
            this.miniTimer_Button_13 = new MiniTimer.Class1.MiniTimer_Button_1();
            this.miniTimer_Button_12 = new MiniTimer.Class1.MiniTimer_Button_1();
            this.miniTimer_Button_11 = new MiniTimer.Class1.MiniTimer_Button_1();
            this.playUI_HeaderLabel1 = new PlayUI.Class1.PlayUI_HeaderLabel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.miniTimer_Label8 = new MiniTimer.Class1.MiniTimer_Label();
            this.miniTimer_Label9 = new MiniTimer.Class1.MiniTimer_Label();
            this.panel6 = new System.Windows.Forms.Panel();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.miniTimer_Label6 = new MiniTimer.Class1.MiniTimer_Label();
            this.miniTimer_Label7 = new MiniTimer.Class1.MiniTimer_Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.miniTimer_Label5 = new MiniTimer.Class1.MiniTimer_Label();
            this.miniTimer_Label4 = new MiniTimer.Class1.MiniTimer_Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.miniTimer_Label3 = new MiniTimer.Class1.MiniTimer_Label();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.miniTimer_Label2 = new MiniTimer.Class1.MiniTimer_Label();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.miniTimer_Label1 = new MiniTimer.Class1.MiniTimer_Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.miniTimer_ThemeContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).BeginInit();
            this.miniTimer_ButtonBase1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // miniTimer_ThemeContainer1
            // 
            this.miniTimer_ThemeContainer1.BackColor = System.Drawing.Color.White;
            this.miniTimer_ThemeContainer1.Controls.Add(this.playUI_Label2);
            this.miniTimer_ThemeContainer1.Controls.Add(this.playUI_Label1);
            this.miniTimer_ThemeContainer1.Controls.Add(this.pictureBox8);
            this.miniTimer_ThemeContainer1.Controls.Add(this.miniTimer_ButtonBase1);
            this.miniTimer_ThemeContainer1.Controls.Add(this.playUI_HeaderLabel1);
            this.miniTimer_ThemeContainer1.Controls.Add(this.panel5);
            this.miniTimer_ThemeContainer1.Controls.Add(this.panel3);
            this.miniTimer_ThemeContainer1.Controls.Add(this.panel1);
            this.miniTimer_ThemeContainer1.Controls.Add(this.pictureBox4);
            this.miniTimer_ThemeContainer1.Controls.Add(this.miniTimer_Label3);
            this.miniTimer_ThemeContainer1.Controls.Add(this.pictureBox3);
            this.miniTimer_ThemeContainer1.Controls.Add(this.miniTimer_Label2);
            this.miniTimer_ThemeContainer1.Controls.Add(this.pictureBox2);
            this.miniTimer_ThemeContainer1.Controls.Add(this.miniTimer_Label1);
            this.miniTimer_ThemeContainer1.Controls.Add(this.pictureBox1);
            this.miniTimer_ThemeContainer1.Cursor = System.Windows.Forms.Cursors.Default;
            this.miniTimer_ThemeContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.miniTimer_ThemeContainer1.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.miniTimer_ThemeContainer1.Location = new System.Drawing.Point(0, 0);
            this.miniTimer_ThemeContainer1.Name = "miniTimer_ThemeContainer1";
            this.miniTimer_ThemeContainer1.Padding = new System.Windows.Forms.Padding(20, 56, 20, 16);
            this.miniTimer_ThemeContainer1.Sizable = false;
            this.miniTimer_ThemeContainer1.Size = new System.Drawing.Size(811, 521);
            this.miniTimer_ThemeContainer1.SmartBounds = false;
            this.miniTimer_ThemeContainer1.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.miniTimer_ThemeContainer1.TabIndex = 0;
            this.miniTimer_ThemeContainer1.Text = "K-Unit AntiVirus";
            this.miniTimer_ThemeContainer1.Click += new System.EventHandler(this.miniTimer_ThemeContainer1_Click);
            this.miniTimer_ThemeContainer1.MouseEnter += new System.EventHandler(this.miniTimer_ThemeContainer1_MouseEnter);
            // 
            // playUI_Label2
            // 
            this.playUI_Label2.AutoSize = true;
            this.playUI_Label2.BackColor = System.Drawing.Color.Transparent;
            this.playUI_Label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playUI_Label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(119)))), ((int)(((byte)(124)))));
            this.playUI_Label2.Location = new System.Drawing.Point(249, 498);
            this.playUI_Label2.Name = "playUI_Label2";
            this.playUI_Label2.Size = new System.Drawing.Size(308, 14);
            this.playUI_Label2.TabIndex = 14;
            this.playUI_Label2.Text = "Developer and Designer: Gopolang Kopano Mathole";
            // 
            // playUI_Label1
            // 
            this.playUI_Label1.AutoSize = true;
            this.playUI_Label1.BackColor = System.Drawing.Color.Transparent;
            this.playUI_Label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playUI_Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(116)))), ((int)(((byte)(119)))), ((int)(((byte)(124)))));
            this.playUI_Label1.Location = new System.Drawing.Point(66, 373);
            this.playUI_Label1.Name = "playUI_Label1";
            this.playUI_Label1.Size = new System.Drawing.Size(0, 12);
            this.playUI_Label1.TabIndex = 13;
            // 
            // pictureBox8
            // 
            this.pictureBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox8.BackgroundImage")));
            this.pictureBox8.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox8.Location = new System.Drawing.Point(491, 74);
            this.pictureBox8.Name = "pictureBox8";
            this.pictureBox8.Size = new System.Drawing.Size(27, 28);
            this.pictureBox8.TabIndex = 12;
            this.pictureBox8.TabStop = false;
            // 
            // miniTimer_ButtonBase1
            // 
            this.miniTimer_ButtonBase1.Controls.Add(this.miniTimer_Button_13);
            this.miniTimer_ButtonBase1.Controls.Add(this.miniTimer_Button_12);
            this.miniTimer_ButtonBase1.Controls.Add(this.miniTimer_Button_11);
            this.miniTimer_ButtonBase1.Location = new System.Drawing.Point(349, 417);
            this.miniTimer_ButtonBase1.Name = "miniTimer_ButtonBase1";
            this.miniTimer_ButtonBase1.Size = new System.Drawing.Size(116, 46);
            this.miniTimer_ButtonBase1.TabIndex = 11;
            this.miniTimer_ButtonBase1.Text = "miniTimer_ButtonBase1";
            // 
            // miniTimer_Button_13
            // 
            this.miniTimer_Button_13.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Button_13.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Button_13.Image = ((System.Drawing.Image)(resources.GetObject("miniTimer_Button_13.Image")));
            this.miniTimer_Button_13.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.miniTimer_Button_13.Location = new System.Drawing.Point(80, 9);
            this.miniTimer_Button_13.Name = "miniTimer_Button_13";
            this.miniTimer_Button_13.Size = new System.Drawing.Size(27, 27);
            this.miniTimer_Button_13.TabIndex = 2;
            this.miniTimer_Button_13.Text = "miniTimer_Button_13";
            // 
            // miniTimer_Button_12
            // 
            this.miniTimer_Button_12.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Button_12.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Button_12.Image = ((System.Drawing.Image)(resources.GetObject("miniTimer_Button_12.Image")));
            this.miniTimer_Button_12.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.miniTimer_Button_12.Location = new System.Drawing.Point(44, 9);
            this.miniTimer_Button_12.Name = "miniTimer_Button_12";
            this.miniTimer_Button_12.Size = new System.Drawing.Size(27, 27);
            this.miniTimer_Button_12.TabIndex = 1;
            this.miniTimer_Button_12.Text = "miniTimer_Button_12";
            // 
            // miniTimer_Button_11
            // 
            this.miniTimer_Button_11.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Button_11.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Button_11.Image = ((System.Drawing.Image)(resources.GetObject("miniTimer_Button_11.Image")));
            this.miniTimer_Button_11.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.miniTimer_Button_11.Location = new System.Drawing.Point(7, 9);
            this.miniTimer_Button_11.Name = "miniTimer_Button_11";
            this.miniTimer_Button_11.Size = new System.Drawing.Size(27, 27);
            this.miniTimer_Button_11.TabIndex = 0;
            this.miniTimer_Button_11.Text = "miniTimer_Button_11";
            // 
            // playUI_HeaderLabel1
            // 
            this.playUI_HeaderLabel1.AutoSize = true;
            this.playUI_HeaderLabel1.BackColor = System.Drawing.Color.Transparent;
            this.playUI_HeaderLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.playUI_HeaderLabel1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.playUI_HeaderLabel1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(47)))), ((int)(((byte)(59)))));
            this.playUI_HeaderLabel1.Location = new System.Drawing.Point(279, 74);
            this.playUI_HeaderLabel1.Name = "playUI_HeaderLabel1";
            this.playUI_HeaderLabel1.Size = new System.Drawing.Size(219, 28);
            this.playUI_HeaderLabel1.TabIndex = 10;
            this.playUI_HeaderLabel1.Text = "You are protected";
            // 
            // panel5
            // 
            this.panel5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.panel5.Controls.Add(this.miniTimer_Label8);
            this.panel5.Controls.Add(this.miniTimer_Label9);
            this.panel5.Controls.Add(this.panel6);
            this.panel5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel5.Location = new System.Drawing.Point(516, 146);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(225, 199);
            this.panel5.TabIndex = 9;
            this.panel5.MouseEnter += new System.EventHandler(this.panel5_MouseEnter);
            this.panel5.MouseLeave += new System.EventHandler(this.panel5_MouseLeave);
            // 
            // miniTimer_Label8
            // 
            this.miniTimer_Label8.AutoSize = true;
            this.miniTimer_Label8.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label8.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label8.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniTimer_Label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(47)))), ((int)(((byte)(59)))));
            this.miniTimer_Label8.Location = new System.Drawing.Point(72, 167);
            this.miniTimer_Label8.Name = "miniTimer_Label8";
            this.miniTimer_Label8.Size = new System.Drawing.Size(79, 16);
            this.miniTimer_Label8.TabIndex = 10;
            this.miniTimer_Label8.Text = "PROTECTED";
            // 
            // miniTimer_Label9
            // 
            this.miniTimer_Label9.AutoSize = true;
            this.miniTimer_Label9.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label9.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label9.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.miniTimer_Label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(201)))));
            this.miniTimer_Label9.Location = new System.Drawing.Point(75, 143);
            this.miniTimer_Label9.Name = "miniTimer_Label9";
            this.miniTimer_Label9.Size = new System.Drawing.Size(71, 18);
            this.miniTimer_Label9.TabIndex = 4;
            this.miniTimer_Label9.Text = "Android";
            // 
            // panel6
            // 
            this.panel6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel6.BackgroundImage")));
            this.panel6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel6.Controls.Add(this.pictureBox7);
            this.panel6.Location = new System.Drawing.Point(46, 35);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(125, 96);
            this.panel6.TabIndex = 8;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox7.BackgroundImage")));
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox7.Location = new System.Drawing.Point(28, 24);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(69, 48);
            this.pictureBox7.TabIndex = 3;
            this.pictureBox7.TabStop = false;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.panel3.Controls.Add(this.miniTimer_Label6);
            this.panel3.Controls.Add(this.miniTimer_Label7);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel3.Location = new System.Drawing.Point(285, 146);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(225, 199);
            this.panel3.TabIndex = 8;
            this.panel3.MouseEnter += new System.EventHandler(this.panel3_MouseEnter);
            this.panel3.MouseLeave += new System.EventHandler(this.panel3_MouseLeave);
            // 
            // miniTimer_Label6
            // 
            this.miniTimer_Label6.AutoSize = true;
            this.miniTimer_Label6.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label6.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label6.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniTimer_Label6.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(47)))), ((int)(((byte)(59)))));
            this.miniTimer_Label6.Location = new System.Drawing.Point(74, 171);
            this.miniTimer_Label6.Name = "miniTimer_Label6";
            this.miniTimer_Label6.Size = new System.Drawing.Size(79, 16);
            this.miniTimer_Label6.TabIndex = 9;
            this.miniTimer_Label6.Text = "PROTECTED";
            // 
            // miniTimer_Label7
            // 
            this.miniTimer_Label7.AutoSize = true;
            this.miniTimer_Label7.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label7.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label7.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.miniTimer_Label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(201)))));
            this.miniTimer_Label7.Location = new System.Drawing.Point(91, 143);
            this.miniTimer_Label7.Name = "miniTimer_Label7";
            this.miniTimer_Label7.Size = new System.Drawing.Size(43, 18);
            this.miniTimer_Label7.TabIndex = 4;
            this.miniTimer_Label7.Text = "Web";
            // 
            // panel4
            // 
            this.panel4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel4.BackgroundImage")));
            this.panel4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel4.Controls.Add(this.pictureBox6);
            this.panel4.Location = new System.Drawing.Point(46, 35);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(125, 96);
            this.panel4.TabIndex = 8;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox6.BackgroundImage")));
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox6.Location = new System.Drawing.Point(28, 24);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(69, 48);
            this.pictureBox6.TabIndex = 3;
            this.pictureBox6.TabStop = false;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(238)))), ((int)(((byte)(238)))), ((int)(((byte)(238)))));
            this.panel1.Controls.Add(this.miniTimer_Label5);
            this.panel1.Controls.Add(this.miniTimer_Label4);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.panel1.Location = new System.Drawing.Point(53, 146);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(225, 199);
            this.panel1.TabIndex = 7;
            this.panel1.MouseEnter += new System.EventHandler(this.panel1_MouseEnter);
            this.panel1.MouseLeave += new System.EventHandler(this.panel1_MouseLeave);
            // 
            // miniTimer_Label5
            // 
            this.miniTimer_Label5.AutoSize = true;
            this.miniTimer_Label5.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label5.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label5.Font = new System.Drawing.Font("Tahoma", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniTimer_Label5.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(42)))), ((int)(((byte)(47)))), ((int)(((byte)(59)))));
            this.miniTimer_Label5.Location = new System.Drawing.Point(73, 171);
            this.miniTimer_Label5.Name = "miniTimer_Label5";
            this.miniTimer_Label5.Size = new System.Drawing.Size(79, 16);
            this.miniTimer_Label5.TabIndex = 9;
            this.miniTimer_Label5.Text = "PROTECTED";
            // 
            // miniTimer_Label4
            // 
            this.miniTimer_Label4.AutoSize = true;
            this.miniTimer_Label4.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label4.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label4.Font = new System.Drawing.Font("Arial Rounded MT Bold", 12F);
            this.miniTimer_Label4.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(201)))));
            this.miniTimer_Label4.Location = new System.Drawing.Point(74, 143);
            this.miniTimer_Label4.Name = "miniTimer_Label4";
            this.miniTimer_Label4.Size = new System.Drawing.Size(87, 18);
            this.miniTimer_Label4.TabIndex = 4;
            this.miniTimer_Label4.Text = "Computer";
            // 
            // panel2
            // 
            this.panel2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("panel2.BackgroundImage")));
            this.panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.panel2.Controls.Add(this.pictureBox5);
            this.panel2.Location = new System.Drawing.Point(46, 35);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(125, 96);
            this.panel2.TabIndex = 8;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox5.BackgroundImage")));
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox5.Location = new System.Drawing.Point(28, 24);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(69, 48);
            this.pictureBox5.TabIndex = 3;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox4
            // 
            this.pictureBox4.BackgroundImage = global::AntiVirus.Properties.Resources.plus;
            this.pictureBox4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox4.Location = new System.Drawing.Point(202, 15);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(20, 17);
            this.pictureBox4.TabIndex = 6;
            this.pictureBox4.TabStop = false;
            // 
            // miniTimer_Label3
            // 
            this.miniTimer_Label3.AutoSize = true;
            this.miniTimer_Label3.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label3.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label3.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniTimer_Label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(201)))));
            this.miniTimer_Label3.Location = new System.Drawing.Point(219, 18);
            this.miniTimer_Label3.Name = "miniTimer_Label3";
            this.miniTimer_Label3.Size = new System.Drawing.Size(98, 12);
            this.miniTimer_Label3.TabIndex = 5;
            this.miniTimer_Label3.Text = "More from K-unit";
            this.miniTimer_Label3.MouseEnter += new System.EventHandler(this.miniTimer_Label3_MouseEnter);
            this.miniTimer_Label3.MouseLeave += new System.EventHandler(this.miniTimer_Label3_MouseLeave);
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox3.BackgroundImage")));
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Location = new System.Drawing.Point(108, 15);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(20, 17);
            this.pictureBox3.TabIndex = 4;
            this.pictureBox3.TabStop = false;
            // 
            // miniTimer_Label2
            // 
            this.miniTimer_Label2.AutoSize = true;
            this.miniTimer_Label2.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label2.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniTimer_Label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(201)))));
            this.miniTimer_Label2.Location = new System.Drawing.Point(127, 18);
            this.miniTimer_Label2.Name = "miniTimer_Label2";
            this.miniTimer_Label2.Size = new System.Drawing.Size(69, 12);
            this.miniTimer_Label2.TabIndex = 3;
            this.miniTimer_Label2.Text = "Buy license";
            this.miniTimer_Label2.MouseEnter += new System.EventHandler(this.miniTimer_Label2_MouseEnter);
            this.miniTimer_Label2.MouseLeave += new System.EventHandler(this.miniTimer_Label2_MouseLeave);
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackgroundImage = global::AntiVirus.Properties.Resources.settings_4;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox2.Location = new System.Drawing.Point(28, 15);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(20, 17);
            this.pictureBox2.TabIndex = 2;
            this.pictureBox2.TabStop = false;
            // 
            // miniTimer_Label1
            // 
            this.miniTimer_Label1.AutoSize = true;
            this.miniTimer_Label1.BackColor = System.Drawing.Color.Transparent;
            this.miniTimer_Label1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.miniTimer_Label1.Font = new System.Drawing.Font("Arial Rounded MT Bold", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.miniTimer_Label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(129)))), ((int)(((byte)(151)))), ((int)(((byte)(201)))));
            this.miniTimer_Label1.Location = new System.Drawing.Point(45, 18);
            this.miniTimer_Label1.Name = "miniTimer_Label1";
            this.miniTimer_Label1.Size = new System.Drawing.Size(50, 12);
            this.miniTimer_Label1.TabIndex = 1;
            this.miniTimer_Label1.Text = "Settings";
            this.miniTimer_Label1.MouseEnter += new System.EventHandler(this.miniTimer_Label1_MouseEnter);
            this.miniTimer_Label1.MouseLeave += new System.EventHandler(this.miniTimer_Label1_MouseLeave);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackgroundImage = global::AntiVirus.Properties.Resources._lock;
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(641, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(41, 32);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(811, 521);
            this.Controls.Add(this.miniTimer_ThemeContainer1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.MinimumSize = new System.Drawing.Size(261, 65);
            this.Name = "Form1";
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "K-Unit AntiVirus";
            this.TransparencyKey = System.Drawing.Color.Fuchsia;
            this.miniTimer_ThemeContainer1.ResumeLayout(false);
            this.miniTimer_ThemeContainer1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox8)).EndInit();
            this.miniTimer_ButtonBase1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.panel6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private MiniTimer.Class1.MiniTimer_ThemeContainer miniTimer_ThemeContainer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label3;
        private System.Windows.Forms.PictureBox pictureBox3;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label2;
        private System.Windows.Forms.Panel panel1;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Panel panel2;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label5;
        private System.Windows.Forms.Panel panel5;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label9;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Panel panel3;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label6;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label7;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.PictureBox pictureBox6;
        private PlayUI.Class1.PlayUI_HeaderLabel playUI_HeaderLabel1;
        private MiniTimer.Class1.MiniTimer_ButtonBase miniTimer_ButtonBase1;
        private MiniTimer.Class1.MiniTimer_Button_1 miniTimer_Button_13;
        private MiniTimer.Class1.MiniTimer_Button_1 miniTimer_Button_12;
        private MiniTimer.Class1.MiniTimer_Button_1 miniTimer_Button_11;
        private MiniTimer.Class1.MiniTimer_Label miniTimer_Label8;
        private System.Windows.Forms.PictureBox pictureBox8;
        private PlayUI.Class1.PlayUI_Label playUI_Label1;
        private PlayUI.Class1.PlayUI_Label playUI_Label2;
    }
}