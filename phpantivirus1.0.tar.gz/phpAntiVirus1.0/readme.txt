PHP AntiVirus 1.0


 CONTENTS
----------

	1. Introduction
	2. Installation
	3. Wanted List
	4. Authors
	5. License


 1.0 INTRODUCTION
------------------

	Welcome to PHP Anti-Virus. I wrote this script because of server
	vulnerabilities that allowed spammers to deface web sites and append spyware
	to any public web site they pleased. Although preventable, it is yet
	undetectable (until a visitor complains, or you next test every page on the
	site).

	This script scans the base web files folder recursively for malicious code
	that may have snuck into publically accessable web files.

	Please note this is version 0.1 and the virus definitions are ridiculously
	empty, with no method for auto update. This is why it is version 0.1 - it
	was written entirely by me for my own server problems. Early days yet - but
	we need your support.


 2.0 INSTALLATION
------------------

	Unpack the archive you just downloaded - it contains this document. Open
	"index.php" in an editor of your choice, and specify a path to scan on line
	number 16:

		file_scan($_SERVER['DOCUMENT_ROOT'], $defs, true);

	$_SERVER['DOCUMENT_ROOT'] should be replaced with something like
	"/home/usrname/htdocs/", i.e. the full path to your web root. In most cases
	that line will work, but I haven't tested it on many platforms.

	Sorry the config is a bit rough :) First version and all that good stuff.

	Save your changes, then upload "index.php" and "virus.def" to your webspace.
	I'd recommend a directory called "av", e.g. http://domain.com/av/

	SET THE FILES 755 OR LOWER. If they are 777, your antivirus could be
	disabled during an attack, rendering it useless.


 3.0 WANTED LIST
-----------------

	This list contains features I'm itching to develop. I haven't had enough
	comments yet to include your desires - I'd like to know though.

	* Complete virus definition list, constantly updated (massive problem!)
	* Better documentation for "non techies"
	* Nicer interface for configuration and scanning
	* Centralised administration for multiple webspaces - script to include an
	  XML connector for local Java(?) client to retrieve and report. Possibly
	  found a Java programmer :)

	Please feel free to e-mail me suggestions at:

		keyboardartist@users.sourceforge.net


 4.0 AUTHORS
-------------

	At the moment it's just myself, FujitsuBoy (aka Keyboard Artist). I hope
	I've found a Java programmer for the centralisable end-client, but new
	members would be very useful. I'm currently looking for:

	* Someone experienced enough to help write virus definition updates
	* Web hosting companies who have seen more exploits than hot dinners
	* PHP "gurus" i.e. if you can't write it blindfold STFU

	Please e-mail me if you have enough time on your hands and you're king of
	your art. I can see a lot of potential in this script - as I say, early
	days!


 5.0 LICENSE
-------------

	This software is licensed under GPL - please read license.txt for the full
	license agreement.
