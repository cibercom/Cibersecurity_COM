<?

// PHP ANTI-VIRUS v1.0
// Written by FujitsuBoy (aka Keyboard Artist)

// readme.txt explains the installation procedure.
// Please see license.txt for licensing information.

// If you have any comments or suggestions please let me know:
// keyboardartist@users.sourceforge.net

// CONFIG -- See readme.txt for instructions

$path = $_SERVER['DOCUMENT_ROOT'];
$debug = true;

// CODE BEGINS -- I probably wouldn't edit this stuff

// output html headers
renderhead();
// set counters
$dircount = 0;
$filecount = 0;
$infected = 0;
// load virus defs from flat file
$defs = load_defs("virus.def", $debug);
// scan specified root for specified defs
file_scan($path, $defs, $debug);
// output summary
echo "<h1>Scan Completed</h2>";
echo "<div id=summary>";
echo "<p><strong>Scanned folders:</strong> " . $dircount . "</p>";
echo "<p><strong>Scanned files:</strong> " . $filecount . "</p>";
echo "<p class=r><strong>Infected files:</strong> " . $infected . "</p>";
echo "</div>";
// output full report
echo $report;



function file_scan($folder, $defs, $debug = true) {
	// hunts files/folders recursively for scannable items
	global $dircount, $report;
	$dircount++;
	if ($debug)
		$report .= "<p class='d'>Scanning folder $folder ...</p>";
	if ($d = @dir($folder)) {
		while (false !== ($entry = $d->read())) {
			$isdir = @is_dir($folder."/".$entry);
			if (!$isdir and $entry!="." and $entry!="..") {
				virus_check($folder."/".$entry,$defs,$debug);
			} elseif ($isdir  and $entry!="." and $entry!="..") {
				file_scan($folder."/".$entry,$defs,$debug);
			}
		}
		$d->close();
	}
}

function virus_check($file, $defs, $debug = true) {
	global $filecount, $infected, $report;
	// find scannables, then compare against defs
	if ((substr($file,-3)=="php")||(substr($file,-3)=="htm")||(substr($file,-3)=="tml")) {
		// affectable formats
		$filecount++;
		$data = file($file);
		$data = implode("\r\n", $data);
		$clean = 1;
		foreach ($defs as $virus) {
			if (strpos($data, $virus[1])) {
				// file matches virus defs
				$report .= "<p class='r'>Infected: " . $file . " (" . $virus[0] . ")</p>";
				$infected++;
				$clean = 0;
			}
		}
		if (($debug)&&($clean))
			$report .= "<p class='g'>Clean: " . $file . "</p>";
	}
}

function load_defs($file, $debug = true) {
	// reads tab-delimited defs file
	$defs = file($file);
	$counter = 0;
	$counttop = sizeof($defs);
	while ($counter < $counttop) {
		$defs[$counter] = explode("	", $defs[$counter]);
		$counter++;
	}
	if ($debug)
		echo "<p>Loaded " . sizeof($defs) . " virus definitions</p>";
	return $defs;
}

function renderhead() {
?>

<html>
<head>
<title>Virus scan</title>
<style type="text/css">
h1 {
	font-family: arial;
}

p {
	font-family: arial;
	padding: 0;
	margin: 0;
	font-size: 10px;
}

.g {
	color: #009900;
}

.r {
	color: #990000;
	font-weight: bold;
}

.d {
	color: #ccc;
}

#summary {
	border: #333 solid 1px;
	background: #f0efca;
	padding: 10px;
	margin: 10px;
}

#summary p {
	font-size: 12px;
}
</style>
</head>

<body>

<?
}
?>

</body>
</html>